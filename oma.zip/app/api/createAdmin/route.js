import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
export async function POST(req) {
  try {
    const body = await req.json();
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    );
    const { data, error } = await supabase.auth.admin.createUser({
      email: body.email,
      password: body.password,
      email_confirm: true,
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ user: data.user }, { status: 200 });
  } catch (e) {
    return NextResponse.json({ error: "Server error: " + e.message }, { status: 500 });
  }
}
