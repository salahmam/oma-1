"use client";

import Link from "next/link";
import { supabase } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const [institutes, setInstitutes] = useState([]);
  const [teachersCount, setTeachersCount] = useState(0);
  const [studentsCount, setStudentsCount] = useState(0);
  const [subjectsCount, setSubjectsCount] = useState(0);

  const loadDashboard = async () => {
    // 1) عدد المعاهد
    const { data: inst } = await supabase
      .from("institutes")
      .select("*");

    setInstitutes(inst || []);

    // 2) عدد المدرسين
    const { count: tCount } = await supabase
      .from("teachers")
      .select("*", { count: "exact", head: true });

    setTeachersCount(tCount || 0);

    // 3) عدد الطلاب
    const { count: sCount } = await supabase
      .from("students")
      .select("*", { count: "exact", head: true });

    setStudentsCount(sCount || 0);

    // 4) عدد المواد
    const { count: subCount } = await supabase
      .from("subjects")
      .select("*", { count: "exact", head: true });

    setSubjectsCount(subCount || 0);
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1 style={{ fontSize: 32, marginBottom: 20 }}>📊 لوحة التحكم</h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 20,
        }}
      >
        {/* عدد الطلاب */}
        <DashboardCard title="عدد الطلاب" value={studentsCount} color="#1976d2" />

        {/* عدد المدرسين */}
        <DashboardCard title="عدد الأساتذة" value={teachersCount} color="#2e7d32" />

        {/* عدد المواد */}
        <DashboardCard title="عدد المواد" value={subjectsCount} color="#8e24aa" />

        {/* عدد المعاهد */}
        <DashboardCard title="عدد المعاهد" value={institutes.length} color="#ff9800" />
      </div>

      <h2 style={{ marginTop: 40 }}>📁 المعاهد</h2>

      <Link
        href="/dashboard/institutes/new"
        style={{
          padding: 12,
          background: "#1976d2",
          color: "white",
          borderRadius: 8,
          textDecoration: "none",
          display: "inline-block",
          marginBottom: 20,
        }}
      >
        ➕ إنشاء معهد جديد
      </Link>

      {institutes.length === 0 ? (
        <p>لا توجد معاهد.</p>
      ) : (
        institutes.map((inst) => (
          <Link
            key={inst.id}
            href={`/dashboard/institutes/${inst.id}`}
            style={{
              display: "block",
              padding: 15,
              marginBottom: 10,
              border: "1px solid #ccc",
              borderRadius: 8,
              textDecoration: "none",
              color: "#000",
            }}
          >
            <strong>{inst.name}</strong>
            <p style={{ margin: 0, color: "#555" }}>
              {inst.description || "بدون وصف"}
            </p>
          </Link>
        ))
      )}
    </div>
  );
}

function DashboardCard({ title, value, color }) {
  return (
    <div
      style={{
        padding: 20,
        background: color,
        color: "white",
        borderRadius: 12,
        textAlign: "center",
        fontSize: 20,
      }}
    >
      <p style={{ margin: 0 }}>{title}</p>
      <h2 style={{ marginTop: 10 }}>{value}</h2>
    </div>
  );
}
