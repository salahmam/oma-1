"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

export default function DashboardLayout({ children }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(true);

  const menu = [
    { label: "لوحة التحكم", icon: "🏠", href: "/dashboard" },
    { label: "المعاهد", icon: "🏫", href: "/dashboard/institutes" },
    { label: "الطلاب", icon: "👨‍🎓", href: "/dashboard/institutes/[id]/students" },
    { label: "الأساتذة", icon: "👨‍🏫", href: "/dashboard/institutes/[id]/teachers" },
    { label: "المواد", icon: "📚", href: "/dashboard/institutes/[id]/subjects" },
    { label: "المراحل", icon: "📘", href: "/dashboard/institutes/[id]/stages" },
    { label: "الكروبات", icon: "👥", href: "/dashboard/institutes/[id]/groups" },
    { label: "الدفعات", icon: "💵", href: "/dashboard/institutes/[id]/payments" },
    { label: "التقارير", icon: "📊", href: "/dashboard/institutes/[id]/reports" },
    { label: "حضور الطلاب", icon: "📝", href: "/dashboard/institutes/[id]/attendance/students" },
    { label: "حضور الأساتذة", icon: "🕒", href: "/dashboard/institutes/[id]/attendance/teachers" },
    { label: "الجدول", icon: "📅", href: "/dashboard/institutes/[id]/schedule" },
    { label: "إدارة المستخدمين", icon: "👤", href: "/dashboard/institutes/[id]/users" },
  ];

  return (
    <div dir="rtl" style={{ display: "flex" }}>
      {/* Sidebar */}
      <div
        style={{
          width: open ? 220 : 70,
          background: "#1f2937",
          color: "white",
          height: "100vh",
          position: "fixed",
          right: 0,
          top: 0,
          paddingTop: 20,
          transition: "0.3s",
        }}
      >
        {/* زر فتح/إغلاق */}
        <button
          onClick={() => setOpen(!open)}
          style={{
            marginRight: 10,
            marginBottom: 20,
            padding: 8,
            background: "#374151",
            color: "white",
            borderRadius: 6,
            border: "none",
            cursor: "pointer",
          }}
        >
          {open ? "⬅️" : "➡️"}
        </button>

        {/* قائمة الروابط */}
        <div style={{ marginTop: 10 }}>
          {menu.map((item, i) => {
            const active = pathname.includes(item.href.split("[id]")[0]);

            return (
              <Link
                key={i}
                href={item.href.replace("[id]", getIdFromPath(pathname))}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "10px 15px",
                  background: active ? "#4b5563" : "transparent",
                  color: "white",
                  textDecoration: "none",
                  fontSize: 15,
                }}
              >
                <span>{item.icon}</span>
                {open && <span>{item.label}</span>}
              </Link>
            );
          })}
        </div>
      </div>

      {/* محتوى الصفحات */}
      <div style={{ marginRight: open ? 230 : 90, flex: 1, transition: "0.3s" }}>
        {children}
      </div>
    </div>
  );
}

// استخراج institute_id من المسار الحالي
function getIdFromPath(path) {
  const parts = path.split("/");
  const idx = parts.indexOf("institutes");
  return idx !== -1 ? parts[idx + 1] : "";
}
