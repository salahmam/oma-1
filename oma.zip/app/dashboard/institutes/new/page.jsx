"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function CreateInstitute() {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const createInstitute = async () => {
    setMsg("");
    setLoading(true);

    // 1 - إنشاء مدير المعهد عبر API
    const res = await fetch("/api/createAdmin", {
      method: "POST",
      body: JSON.stringify({ email, password: pass }),
    });

    const json = await res.json();

    if (!res.ok) {
      setLoading(false);
      setMsg("خطأ في إنشاء حساب المدير: " + json.error);
      return;
    }

    const userId = json.user.id;

    // 2 - إنشاء المعهد
    const { data: institute, error: instErr } = await supabase
      .from("institutes")
      .insert([{ name, description: desc }])
      .select()
      .single();

    if (instErr) {
      setLoading(false);
      setMsg("خطأ في إنشاء المعهد: " + instErr.message);
      return;
    }

    const instituteId = institute.id;

    // 3 - إضافة المدير إلى profiles
    const { error: profErr } = await supabase
      .from("profiles")
      .insert([
        {
          id: userId,
          full_name: name + " - مدير",
          role: "admin",
          institute_id: instituteId,
        },
      ]);

    if (profErr) {
      setLoading(false);
      setMsg("خطأ في ربط المدير بالمعهد: " + profErr.message);
      return;
    }

    setLoading(false);
    setMsg("🎉 تم إنشاء المعهد مع حساب المدير بنجاح!");
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1 style={{ fontSize: 30, marginBottom: 20 }}>إنشاء معهد جديد</h1>

      <input
        type="text"
        placeholder="اسم المعهد"
        onChange={(e) => setName(e.target.value)}
        style={{ display: "block", marginBottom: 10, padding: 10, width: "100%" }}
      />

      <textarea
        placeholder="وصف المعهد"
        onChange={(e) => setDesc(e.target.value)}
        style={{ display: "block", marginBottom: 10, padding: 10, width: "100%" }}
      />

      <input
        type="email"
        placeholder="إيميل مدير المعهد"
        onChange={(e) => setEmail(e.target.value)}
        style={{ display: "block", marginBottom: 10, padding: 10, width: "100%" }}
      />

      <input
        type="password"
        placeholder="كلمة المرور"
        onChange={(e) => setPass(e.target.value)}
        style={{ display: "block", marginBottom: 10, padding: 10, width: "100%" }}
      />

      <button
        onClick={createInstitute}
        disabled={loading}
        style={{
          background: "#1e88e5",
          color: "white",
          padding: 12,
          width: "100%",
          borderRadius: 6,
        }}
      >
        {loading ? "جاري الإنشاء..." : "إنشاء المعهد"}
      </button>

      {msg && (
        <p style={{ marginTop: 20, fontWeight: "bold" }}>
          {msg}
        </p>
      )}
    </div>
  );
}
