"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function TeacherAttendanceLog() {
  const { id } = useParams();
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [records, setRecords] = useState([]);

  const loadLog = async () => {
    const { data } = await supabase
      .from("attendance_teachers")
      .select("*, teachers(full_name,subject_name)")
      .eq("institute_id", id)
      .eq("date", date)
      .order("created_at", { ascending: true });

    setRecords(data || []);
  };

  useEffect(() => {
    loadLog();
  }, [date]);

  const cellStyle = {
    padding: 10,
    border: "1px solid #ccc",
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📅 سجل حضور الأساتذة</h1>

      <label style={{ fontSize: 18 }}>اختر التاريخ:</label>
      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        style={{ padding: 10, marginTop: 10, marginBottom: 20 }}
      />

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          textAlign: "center",
        }}
      >
        <thead>
          <tr style={{ background: "#e0e0e0" }}>
            <th style={cellStyle}>الأستاذ</th>
            <th style={cellStyle}>المادة</th>
            <th style={cellStyle}>الحالة</th>
          </tr>
        </thead>

        <tbody>
          {records.map((r) => (
            <tr key={r.id}>
              <td style={cellStyle}>{r.teachers?.full_name}</td>
              <td style={cellStyle}>{r.teachers?.subject_name}</td>
              <td style={cellStyle}>
                {r.status === "present" ? (
                  <span style={{ color: "green" }}>✔ حاضر</span>
                ) : (
                  <span style={{ color: "red" }}>✖ غائب</span>
                )}
              </td>
            </tr>
          ))}

          {records.length === 0 && (
            <tr>
              <td colSpan={3} style={cellStyle}>
                لا توجد بيانات لهذا اليوم
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
