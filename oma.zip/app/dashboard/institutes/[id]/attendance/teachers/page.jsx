"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function TeacherAttendance() {
  const { id } = useParams();
  const [teachers, setTeachers] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    supabase
      .from("teachers")
      .select("*")
      .eq("institute_id", id)
      .then(({ data }) => setTeachers(data || []));
  }, []);

  const markAttendance = async (teacherId, status) => {
    const today = new Date().toISOString().split("T")[0];

    await supabase.from("attendance_teachers").upsert([
      {
        teacher_id: teacherId,
        institute_id: id,
        date: today,
        status,
      },
    ]);

    setMsg("تم حفظ حضور الأستاذ ✔️");
    setTimeout(() => setMsg(""), 2000);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>🕒 حضور الأساتذة</h1>

      {teachers.map((t) => (
        <div
          key={t.id}
          style={{
            padding: 12,
            border: "1px solid #ccc",
            borderRadius: 8,
            marginBottom: 10,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <span>{t.full_name}</span>

          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={() => markAttendance(t.id, "present")}
              style={{
                padding: "5px 10px",
                background: "green",
                color: "white",
                borderRadius: 6,
              }}
            >
              ✔️ حاضر
            </button>
            <button
              onClick={() => markAttendance(t.id, "absent")}
              style={{
                padding: "5px 10px",
                background: "red",
                color: "white",
                borderRadius: 6,
              }}
            >
              ❌ غياب
            </button>
          </div>
        </div>
      ))}

      {msg && <p style={{ color: "green" }}>{msg}</p>}
    </div>
  );
}
