
"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function StudentAttendance() {
  const { id } = useParams();
  const [students, setStudents] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    supabase
      .from("students")
      .select("*")
      .eq("institute_id", id)
      .then(({ data }) => setStudents(data || []));
  }, []);

  const markAttendance = async (studentId, status) => {
    const today = new Date().toISOString().split("T")[0];

    await supabase.from("attendance_students").upsert([
      {
        student_id: studentId,
        institute_id: id,
        date: today,
        status,
      },
    ]);

    setMsg("تم حفظ الحضور ✔️");
    setTimeout(() => setMsg(""), 2000);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📝 حضور الطلاب</h1>

      {students.map((s) => (
        <div
          key={s.id}
          style={{
            padding: 12,
            border: "1px solid #ccc",
            borderRadius: 8,
            marginBottom: 10,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <span>{s.full_name}</span>

          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={() => markAttendance(s.id, "present")}
              style={{
                padding: "5px 10px",
                background: "green",
                color: "white",
                borderRadius: 6,
              }}
            >
              ✔️ حاضر
            </button>
            <button
              onClick={() => markAttendance(s.id, "absent")}
              style={{
                padding: "5px 10px",
                background: "red",
                color: "white",
                borderRadius: 6,
              }}
            >
              ❌ غياب
            </button>
          </div>
        </div>
      ))}

      {msg && <p style={{ color: "green" }}>{msg}</p>}
    </div>
  );
}
