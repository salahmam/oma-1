"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function NewStage() {
  const { id } = useParams(); 
  const router = useRouter();

  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");

  const saveStage = async () => {
    if (!name) {
      setMsg("يرجى كتابة اسم المرحلة");
      return;
    }

    const { error } = await supabase.from("stages").insert([
      {
        name,
        institute_id: id,
      },
    ]);

    if (error) {
      setMsg("خطأ: " + error.message);
      return;
    }

    router.push(`/dashboard/institutes/${id}/stages`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>➕ إضافة مرحلة جديدة</h1>

      <input
        style={{ padding: 12, borderRadius: 8, border: "1px solid #ccc", width: 300 }}
        placeholder="مثال: سادس أدبي"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button
        style={{
          padding: 12,
          background: "#2e7d32",
          color: "white",
          borderRadius: 8,
          marginTop: 12,
        }}
        onClick={saveStage}
      >
        💾 حفظ
      </button>

      {msg && <p style={{ color: "red" }}>{msg}</p>}
    </div>
  );
}
