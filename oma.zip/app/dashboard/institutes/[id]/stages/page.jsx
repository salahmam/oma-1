"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function StagesPage() {
  const { id } = useParams();
  const router = useRouter();

  const [stages, setStages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const loadStages = async () => {
      const { data, error } = await supabase
        .from("stages")
        .select("*")
        .eq("institute_id", id)
        .order("level");

      if (error) {
        setMsg("خطأ في تحميل المراحل: " + error.message);
      } else {
        setStages(data || []);
      }

      setLoading(false);
    };

    loadStages();
  }, [id]);

  if (loading)
    return <p style={{ padding: 40 }}>جاري تحميل المراحل...</p>;

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📘 المراحل الدراسية</h1>

      <button
        onClick={() => router.push(`/dashboard/institutes/${id}/stages/new`)}
        style={{
          padding: 12,
          background: "#3949ab",
          color: "white",
          borderRadius: 8,
          marginTop: 20,
        }}
      >
        ➕ إضافة مرحلة جديدة
      </button>

      {msg && <p style={{ color: "red", marginTop: 20 }}>{msg}</p>}

      <div style={{ marginTop: 25 }}>
        {stages.map((s) => (
          <div
            key={s.id}
            style={{
              padding: 15,
              border: "1px solid #ccc",
              borderRadius: 10,
              marginBottom: 10,
            }}
          >
            <p style={{ fontSize: 18 }}>📘 {s.name}</p>
          </div>
        ))}

        {stages.length === 0 && (
          <p style={{ color: "gray" }}>لا توجد مراحل بعد.</p>
        )}
      </div>
    </div>
  );
}
