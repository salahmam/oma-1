"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function NewSubject() {
  const { id } = useParams(); // institute id
  const router = useRouter();

  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");

  const saveSubject = async () => {
    if (!name.trim()) {
      setMsg("يرجى إدخال اسم المادة");
      return;
    }

    const { error } = await supabase.from("subjects").insert([
      {
        name,
        institute_id: id,
      },
    ]);

    if (error) {
      setMsg("خطأ: " + error.message);
      return;
    }

    router.push(`/dashboard/institutes/${id}/subjects`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>➕ إضافة مادة جديدة</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 20 }}>
        <label>اسم المادة</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="مثال: رياضيات"
          style={{
            padding: 10,
            border: "1px solid #aaa",
            borderRadius: 8,
          }}
        />

        <button
          onClick={saveSubject}
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
            marginTop: 10,
          }}
        >
          💾 حفظ المادة
        </button>

        {msg && <p style={{ color: "red" }}>{msg}</p>}
      </div>
    </div>
  );
}
