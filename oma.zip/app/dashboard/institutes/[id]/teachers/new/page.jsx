"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function NewTeacher() {
  const { id } = useParams(); // institute_id
  const router = useRouter();

  const [fullName, setFullName] = useState("");
  const [subjectName, setSubjectName] = useState("");
  const [phone, setPhone] = useState("");
  const [stage, setStage] = useState("");
  const [msg, setMsg] = useState("");

  const saveTeacher = async () => {
    setMsg("");

    if (!fullName || !subjectName) {
      setMsg("يرجى كتابة اسم الأستاذ والمادة");
      return;
    }

    // 1️⃣ حفظ بيانات الأستاذ أولاً
    const { data: teacherData, error: teacherError } = await supabase
      .from("teachers")
      .insert([
        {
          full_name: fullName,
          subject_name: subjectName, // للمشاهدة فقط
          phone,
          stage,
          institute_id: id,
        },
      ])
      .select("id")
      .single();

    if (teacherError) {
      setMsg("خطأ أثناء حفظ المدرّس: " + teacherError.message);
      return;
    }

    const teacherId = teacherData.id;

    // 2️⃣ إنشاء المادة تلقائيًا وربطها بالأستاذ
    const { error: subjectError } = await supabase
      .from("subjects")
      .insert([
        {
          name: subjectName,   // اسم المادة
          teacher_id: teacherId,
          institute_id: id,
        },
      ]);

    if (subjectError) {
      setMsg("تم حفظ المدرّس، لكن حدث خطأ في حفظ المادة: " + subjectError.message);
      return;
    }

    // 3️⃣ الانتهاء
    setMsg("تم حفظ الأستاذ والمادة بنجاح 🎉");
    router.push(`/dashboard/institutes/${id}/teachers`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>➕ إضافة أستاذ جديد</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <label>اسم الأستاذ</label>
        <input
          style={{ padding: 10 }}
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
        />

        <label>المادة</label>
        <input
          style={{ padding: 10 }}
          value={subjectName}
          onChange={(e) => setSubjectName(e.target.value)}
          placeholder="مثال: رياضيات سادس علمي"
        />

        <label>المرحلة</label>
        <input
          style={{ padding: 10 }}
          value={stage}
          onChange={(e) => setStage(e.target.value)}
        />

        <label>هاتف الأستاذ</label>
        <input
          style={{ padding: 10 }}
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />

        <button
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
          }}
          onClick={saveTeacher}
        >
          💾 حفظ
        </button>

        {msg && <p style={{ color: msg.includes("خطأ") ? "red" : "green" }}>{msg}</p>}
      </div>
    </div>
  );
}
