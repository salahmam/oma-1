"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function TeacherPrintPage() {
  const params = useParams();
  const instituteId = params.id;
  const teacherId = params.teacherId;

  const [loading, setLoading] = useState(true);
  const [teacher, setTeacher] = useState(null);
  const [institute, setInstitute] = useState(null);
  const [totals, setTotals] = useState({
    totalShare: 0,
    studentsPaid: 0,
    remainingOnStudents: 0,
    teacherWithdrawn: 0,
    remainingForTeacher: 0,
  });

  const loadData = async () => {
    setLoading(true);

    const { data: tData } = await supabase
      .from("teachers")
      .select("*")
      .eq("id", teacherId)
      .single();

    const { data: instData } = await supabase
      .from("institutes")
      .select("*")
      .eq("id", instituteId)
      .single();

    const { data: ssData } = await supabase
      .from("student_subjects")
      .select("teacher_share")
      .eq("teacher_id", teacherId);

    const { data: payData } = await supabase
      .from("student_payments")
      .select("amount")
      .eq("teacher_id", teacherId);

    const { data: wData } = await supabase
      .from("teacher_withdrawals")
      .select("amount")
      .eq("teacher_id", teacherId);

    setTeacher(tData || null);
    setInstitute(instData || null);

    const totalShare = (ssData || []).reduce(
      (sum, row) => sum + Number(row.teacher_share || 0),
      0
    );
    const studentsPaid = (payData || []).reduce(
      (sum, row) => sum + Number(row.amount || 0),
      0
    );
    const teacherWithdrawn = (wData || []).reduce(
      (sum, row) => sum + Number(row.amount || 0),
      0
    );

    const remainingOnStudents = totalShare - studentsPaid;
    const remainingForTeacher = totalShare - teacherWithdrawn;

    setTotals({
      totalShare,
      studentsPaid,
      remainingOnStudents,
      teacherWithdrawn,
      remainingForTeacher,
    });

    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading || !teacher || !institute) {
    return <p style={{ padding: 40 }}>جاري تجهيز تقرير الطباعة...</p>;
  }

  const primaryColor = institute.primary_color || "#1976d2";
  const today = new Date().toLocaleDateString("ar-IQ");

  return (
    <div dir="rtl">
      <style jsx>{`
        @media print {
          .no-print {
            display: none;
          }
          body {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
        }
      `}</style>

      {/* زر الطباعة */}
      <div className="no-print" style={{ padding: 20, textAlign: "center" }}>
        <button
          onClick={() => window.print()}
          style={{
            padding: 10,
            background: primaryColor,
            color: "white",
            borderRadius: 8,
            border: "none",
            cursor: "pointer",
            minWidth: 150,
          }}
        >
          🖨 طباعة
        </button>
      </div>

      {/* محتوى صفحة A4 */}
      <div
        style={{
          width: "210mm",
          minHeight: "297mm",
          margin: "0 auto",
          padding: "20mm",
          boxSizing: "border-box",
          fontFamily: "system-ui, sans-serif",
          background: "#fff",
          boxShadow: "0 0 5px rgba(0,0,0,0.1)",
        }}
      >
        {/* الهيدر */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            borderBottom: `3px solid ${primaryColor}`,
            paddingBottom: 10,
            marginBottom: 20,
          }}
        >
          {institute.logo_url && (
            <img
              src={institute.logo_url}
              alt="شعار المعهد"
              style={{ width: 80, height: 80, objectFit: "contain", marginLeft: 20 }}
            />
          )}
          <div style={{ flex: 1 }}>
            <h1
              style={{
                margin: 0,
                fontSize: 26,
                color: primaryColor,
              }}
            >
              {institute.name}
            </h1>
            <p style={{ margin: 0, color: "#555" }}>تقرير تفصيلي عن الأستاذ</p>
          </div>
          <div style={{ textAlign: "left", fontSize: 12, color: "#555" }}>
            <p style={{ margin: 0 }}>التاريخ: {today}</p>
          </div>
        </div>

        {/* بيانات الأستاذ */}
        <div style={{ marginBottom: 20 }}>
          <h2 style={{ margin: "0 0 10px 0", fontSize: 20 }}>بيانات الأستاذ</h2>
          <table
            style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}
          >
            <tbody>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  اسم الأستاذ
                </td>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  {teacher.full_name}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  المادة
                </td>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  {teacher.subject || "غير محددة"}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  المرحلة
                </td>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  {teacher.stage || "غير محددة"}
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  رقم الهاتف
                </td>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  {teacher.phone || "لا يوجد"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* الملخص المالي */}
        <div style={{ marginBottom: 20 }}>
          <h2 style={{ margin: "0 0 10px 0", fontSize: 20 }}>الملخص المالي</h2>
          <table
            style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}
          >
            <tbody>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  مجموع مستحقات الأستاذ الكاملة (بعد خصم نسبة المعهد)
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    textAlign: "center",
                  }}
                >
                  {totals.totalShare.toFixed(0)} د.ع
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  مجموع ما دفعه الطلاب حتى الآن
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    textAlign: "center",
                  }}
                >
                  {totals.studentsPaid.toFixed(0)} د.ع
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  المتبقي على الطلاب (ذمم لم تُحصّل بعد)
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    textAlign: "center",
                  }}
                >
                  {totals.remainingOnStudents.toFixed(0)} د.ع
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid #ddd", padding: 6 }}>
                  مجموع ما استلمه الأستاذ من المعهد
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    textAlign: "center",
                  }}
                >
                  {totals.teacherWithdrawn.toFixed(0)} د.ع
                </td>
              </tr>
              <tr>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    fontWeight: "bold",
                  }}
                >
                  المتبقي للأستاذ (مستحق على المعهد)
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: 6,
                    textAlign: "center",
                    fontWeight: "bold",
                    color: "#c62828",
                  }}
                >
                  {totals.remainingForTeacher.toFixed(0)} د.ع
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* تذييل للطباعة */}
        <div
          style={{
            marginTop: 40,
            display: "flex",
            justifyContent: "space-between",
            fontSize: 14,
          }}
        >
          <div>
            <p style={{ marginBottom: 40 }}>توقيع إدارة المعهد:</p>
            <p>___________________________</p>
          </div>
          <div>
            <p style={{ marginBottom: 40 }}>توقيع الأستاذ:</p>
            <p>___________________________</p>
          </div>
        </div>
      </div>
    </div>
  );
}
