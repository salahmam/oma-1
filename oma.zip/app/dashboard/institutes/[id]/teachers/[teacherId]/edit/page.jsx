"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function EditTeacher() {
  const { id, teacherId } = useParams();
  const router = useRouter();

  const [fullName, setFullName] = useState("");
  const [subjectName, setSubjectName] = useState("");
  const [phone, setPhone] = useState("");
  const [stage, setStage] = useState("");
  const [msg, setMsg] = useState("");

  const loadTeacher = async () => {
    const { data } = await supabase
      .from("teachers")
      .select("*")
      .eq("id", teacherId)
      .single();

    if (data) {
      setFullName(data.full_name);
      setSubjectName(data.subject_name);
      setPhone(data.phone);
      setStage(data.stage);
    }
  };

  useEffect(() => {
    loadTeacher();
  }, []);

  const save = async () => {
    const { error } = await supabase
      .from("teachers")
      .update({
        full_name: fullName,
        subject_name: subjectName,
        phone,
        stage,
      })
      .eq("id", teacherId);

    if (error) {
      setMsg("خطأ: " + error.message);
      return;
    }

    router.push(`/dashboard/institutes/${id}/teachers/${teacherId}`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>✏️ تعديل بيانات الأستاذ</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <label>اسم الأستاذ</label>
        <input
          style={{ padding: 10 }}
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
        />

        <label>المادة</label>
        <input
          style={{ padding: 10 }}
          value={subjectName}
          onChange={(e) => setSubjectName(e.target.value)}
          placeholder="مثال: رياضيات"
        />

        <label>هاتف الأستاذ</label>
        <input
          style={{ padding: 10 }}
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />

        <label>المرحلة</label>
        <input
          style={{ padding: 10 }}
          value={stage}
          onChange={(e) => setStage(e.target.value)}
        />

        <button
          onClick={save}
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
          }}
        >
          💾 حفظ
        </button>

        {msg && <p style={{ color: "red" }}>{msg}</p>}
      </div>
    </div>
  );
}
