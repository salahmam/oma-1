"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function TeacherPage() {
  const { id, teacherId } = useParams(); // institute + teacher
  const router = useRouter();

  const [teacher, setTeacher] = useState(null);
  const [students, setStudents] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [teacherPaid, setTeacherPaid] = useState(0);
  const [msg, setMsg] = useState("");

  const loadData = async () => {
    // تحميل بيانات الأستاذ
    const { data: tData } = await supabase
      .from("teachers")
      .select("*")
      .eq("id", teacherId)
      .single();

    setTeacher(tData);
    setTeacherPaid(tData.teacher_paid || 0);

    // جلب مواد الطلاب المرتبطة بالأستاذ
    const { data: ssData } = await supabase
      .from("student_subjects")
      .select("*, students(full_name, phone)")
      .eq("teacher_id", teacherId);

    setStudents(ssData || []);

    // حساب مجموع مبالغ الطلاب
    const sum = (ssData || []).reduce((acc, s) => acc + Number(s.total_fee), 0);
    setTotalAmount(sum);
  };

  useEffect(() => {
    loadData();
  }, []);

  if (!teacher) {
    return <p style={{ padding: 40 }}>جاري تحميل بيانات الأستاذ...</p>;
  }

  // حساب المتبقي للأستاذ
  const remaining = totalAmount - teacherPaid;

  // حذف الأستاذ
  const deleteTeacher = async () => {
    if (!confirm("هل تريد حذف هذا الأستاذ؟ سيتم حذف بياناته بالكامل!")) return;

    await supabase.from("teachers").delete().eq("id", teacherId);

    router.push(`/dashboard/institutes/${id}/teachers`);
  };

  return (
    <div dir="rtl" style={{ padding: 40, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ fontSize: 28, marginBottom: 20 }}>
        👨‍🏫 الأستاذ: {teacher.full_name}
      </h1>

      {/* بطاقة معلومات الأستاذ */}
      <div
        style={{
          background: "#f8f8f8",
          padding: 20,
          borderRadius: 10,
          marginBottom: 25,
        }}
      >
        <p>📘 المادة: {teacher.subject_name}</p>
        <p>📚 المرحلة: {teacher.stage || "—"}</p>
        <p>📞 الهاتف: {teacher.phone}</p>

        <hr style={{ margin: "20px 0" }} />

        <h3>💰 الحساب المالي</h3>
        <p>مجموع مبالغ طلابه: {totalAmount} د.ع</p>
        <p>ما استلمه: {teacherPaid} د.ع</p>
        <p style={{ color: remaining > 0 ? "red" : "green" }}>
          المتبقي له: {remaining} د.ع
        </p>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 30 }}>
        <button
          onClick={() =>
            router.push(
              `/dashboard/institutes/${id}/teachers/${teacherId}/edit`
            )
          }
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
          }}
        >
          ✏️ تعديل
        </button>

        <button
          onClick={() =>
            router.push(
              `/dashboard/institutes/${id}/teachers/${teacherId}/print`
            )
          }
          style={{
            padding: 12,
            background: "#444",
            color: "white",
            borderRadius: 8,
          }}
        >
          🖨️ طباعة
        </button>

        <button
          onClick={deleteTeacher}
          style={{
            padding: 12,
            background: "darkred",
            color: "white",
            borderRadius: 8,
            marginRight: "auto",
          }}
        >
          🗑️ حذف
        </button>
      </div>

      {/* قائمة الطلاب */}
      <h2>👨‍🎓 طلاب الأستاذ ({students.length})</h2>

      {students.length === 0 ? (
        <p>لا يوجد طلاب مرتبطون بهذا الأستاذ.</p>
      ) : (
        students.map((s) => (
          <div
            key={s.id}
            style={{
              padding: 15,
              border: "1px solid #ccc",
              borderRadius: 10,
              marginTop: 10,
            }}
          >
            <p style={{ fontSize: 18 }}>
              👤 {s.students.full_name}  
            </p>
            <p>💵 سعر المادة: {s.total_fee} د.ع</p>
            <p>📱 هاتفه: {s.students.phone}</p>
          </div>
        ))
      )}

      {msg && <p style={{ color: "red" }}>{msg}</p>}
    </div>
  );
}
