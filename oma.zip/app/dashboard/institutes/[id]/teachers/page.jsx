"use client";

import Link from "next/link";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function TeachersList() {
  const { id } = useParams();
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadTeachers = async () => {
    const { data } = await supabase
      .from("teachers")
      .select("id, full_name, subject_name, phone")
      .eq("institute_id", id)
      .order("full_name", { ascending: true });

    setTeachers(data || []);
    setLoading(false);
  };

  useEffect(() => {
    loadTeachers();
  }, []);

  if (loading) return <p style={{ padding: 40 }}>جاري التحميل...</p>;

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>👨‍🏫 قائمة الأساتذة</h1>

      <Link
        href={`/dashboard/institutes/${id}/teachers/new`}
        style={{
          padding: 12,
          background: "#1976d2",
          color: "white",
          borderRadius: 8,
          textDecoration: "none",
          display: "inline-block",
          marginBottom: 20,
        }}
      >
        ➕ إضافة أستاذ جديد
      </Link>

      {teachers.length === 0 ? (
        <p>لا يوجد أساتذة.</p>
      ) : (
        teachers.map((t) => (
          <div
            key={t.id}
            style={{
              padding: 15,
              border: "1px solid #ccc",
              borderRadius: 8,
              marginTop: 10,
            }}
          >
            <strong>{t.full_name}</strong>
            <p style={{ margin: "5px 0" }}>📘 {t.subject_name}</p>
            <p style={{ margin: 0 }}>📞 {t.phone || "—"}</p>

            <Link
              href={`/dashboard/institutes/${id}/teachers/${t.id}`}
              style={{
                marginTop: 10,
                display: "inline-block",
                padding: 8,
                background: "#00796b",
                color: "white",
                borderRadius: 6,
                textDecoration: "none",
              }}
            >
              👁 عرض التفاصيل
            </Link>
          </div>
        ))
      )}
    </div>
  );
}
