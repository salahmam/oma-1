"use client";

import Link from "next/link";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function StudentsList() {
  const { id } = useParams(); // id = institute_id
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");

  const load = async () => {
    setLoading(true);
    setMsg("");

    const { data, error } = await supabase
      .from("students")
      .select("*")
      .eq("institute_id", id)
      .order("full_name", { ascending: true });

    if (error) {
      setMsg("خطأ في تحميل قائمة الطلاب: " + error.message);
    } else {
      setStudents(data || []);
    }

    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  if (loading) {
    return <p style={{ padding: 40 }}>جاري تحميل قائمة الطلاب...</p>;
  }

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1 style={{ marginBottom: 20 }}>👨‍🎓 قائمة الطلاب</h1>

      <Link
        href={`/dashboard/institutes/${id}/students/new`}
        style={{
          padding: 12,
          display: "inline-block",
          background: "#1976d2",
          color: "white",
          borderRadius: 8,
          marginBottom: 20,
          textDecoration: "none",
        }}
      >
        ➕ إضافة طالب جديد
      </Link>

      {msg && (
        <p style={{ color: "red", marginTop: 10 }}>
          {msg}
        </p>
      )}

      {students.length === 0 ? (
        <p>لا يوجد طلاب بعد.</p>
      ) : (
        students.map((s) => (
          <div
            key={s.id}
            style={{
              padding: 15,
              border: "1px solid #ccc",
              marginTop: 10,
              borderRadius: 8,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div>
                <strong>{s.full_name}</strong>
                <p style={{ margin: 0, color: "#555" }}>
                  📞 {s.phone || "لا يوجد رقم"}
                </p>
                <p style={{ margin: 0, color: "#777", fontSize: 13 }}>
                  المرحلة: {s.stage || "—"} | الكروب: {s.group_name || "—"}
                </p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <Link
                  href={`/dashboard/institutes/${id}/students/${s.id}`}
                  style={{
                    padding: 8,
                    background: "#00796b",
                    color: "white",
                    borderRadius: 6,
                    textDecoration: "none",
                    textAlign: "center",
                    minWidth: 120,
                  }}
                >
                  👁 عرض البيانات
                </Link>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
