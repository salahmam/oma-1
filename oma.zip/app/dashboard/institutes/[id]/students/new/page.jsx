"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function NewStudentPage() {
  const { id } = useParams(); // institute_id
  const router = useRouter();

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [parentPhone, setParentPhone] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [gender, setGender] = useState("ذكر");
  const [school, setSchool] = useState("");

  const [stageId, setStageId] = useState("");
  const [groupId, setGroupId] = useState("");

  const [stages, setStages] = useState([]);
  const [groups, setGroups] = useState([]);

  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const loadLookups = async () => {
    setMsg("");

    // المراحل
    const { data: stagesData, error: stagesError } = await supabase
      .from("stages")
      .select("*")
      .eq("institute_id", id)
      .order("name", { ascending: true });

    if (stagesError) {
      setMsg("خطأ في تحميل المراحل: " + stagesError.message);
    } else {
      setStages(stagesData || []);
    }

    // الكروبات
    const { data: groupsData, error: groupsError } = await supabase
      .from("groups")
      .select("*")
      .eq("institute_id", id)
      .order("name", { ascending: true });

    if (groupsError) {
      setMsg((prev) => prev + "\nخطأ في تحميل الكروبات: " + groupsError.message);
    } else {
      setGroups(groupsData || []);
    }
  };

  useEffect(() => {
    loadLookups();
  }, []);

  const saveStudent = async (e) => {
    e.preventDefault();
    setMsg("");
    setSaving(true);

    // إيجاد أسماء المرحلة والكروب من الجداول
    const stageObj = stages.find((s) => s.id === stageId) || null;
    const groupObj = groups.find((g) => g.id === groupId) || null;

    const { data, error } = await supabase.from("students").insert([
      {
        full_name: fullName,
        phone,
        parent_phone: parentPhone,
        birth_date: birthDate || null,
        gender,
        school,
        institute_id: id,

        // أعمدة قديمة للحفاظ على التوافق
        stage: stageObj ? stageObj.name : null,
        stage_id: stageObj ? stageObj.id : null,
        group_name: groupObj ? groupObj.name : null,
        group_id: groupObj ? groupObj.id : null,
      },
    ]).select("id").single();

    if (error) {
      setMsg("خطأ في حفظ بيانات الطالب: " + error.message);
      setSaving(false);
      return;
    }

    setMsg("تم حفظ الطالب بنجاح ✅");
    // بعد الحفظ نذهب إلى صفحة الطالب
    router.push(`/dashboard/institutes/${id}/students/${data.id}`);
  };

  return (
    <div dir="rtl" style={{ padding: 40, maxWidth: 700, margin: "0 auto" }}>
      <h1 style={{ marginBottom: 20 }}>➕ إضافة طالب جديد</h1>

      <form onSubmit={saveStudent} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <input
          type="text"
          required
          placeholder="اسم الطالب الكامل"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          style={{ padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
        />

        <input
          type="text"
          placeholder="مدرسة الطالب"
          value={school}
          onChange={(e) => setSchool(e.target.value)}
          style={{ padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
        />

        <div style={{ display: "flex", gap: 10 }}>
          <input
            type="text"
            placeholder="هاتف الطالب"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            style={{ flex: 1, padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
          />
          <input
            type="text"
            placeholder="هاتف ولي الأمر"
            value={parentPhone}
            onChange={(e) => setParentPhone(e.target.value)}
            style={{ flex: 1, padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
          />
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ flex: 1 }}>
            <label>تاريخ الميلاد</label>
            <input
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              style={{ width: "100%", padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
            />
          </div>

          <div style={{ flex: 1 }}>
            <label>الجنس</label>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value)}
              style={{ width: "100%", padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
            >
              <option value="ذكر">ذكر</option>
              <option value="أنثى">أنثى</option>
            </select>
          </div>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ flex: 1 }}>
            <label>المرحلة</label>
            <select
              value={stageId}
              onChange={(e) => setStageId(e.target.value)}
              style={{ width: "100%", padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
            >
              <option value="">اختر المرحلة</option>
              {stages.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>

          <div style={{ flex: 1 }}>
            <label>الكروب</label>
            <select
              value={groupId}
              onChange={(e) => setGroupId(e.target.value)}
              style={{ width: "100%", padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
            >
              <option value="">اختر الكروب</option>
              {groups.map((gr) => (
                <option key={gr.id} value={gr.id}>
                  {gr.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          style={{
            padding: 12,
            background: "#2e7d32",
            color: "white",
            borderRadius: 8,
            border: "none",
            marginTop: 10,
            cursor: "pointer",
          }}
        >
          {saving ? "جارٍ الحفظ..." : "💾 حفظ الطالب"}
        </button>
      </form>

      {msg && (
        <p style={{ color: msg.includes("خطأ") ? "red" : "green", marginTop: 20 }}>
          {msg}
        </p>
      )}
    </div>
  );
}
