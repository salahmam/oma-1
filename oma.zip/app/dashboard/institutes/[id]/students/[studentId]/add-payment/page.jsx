"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function AddPayment() {
  const { id, studentId } = useParams();
  const router = useRouter();

  const [subjects, setSubjects] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [sharePercent, setSharePercent] = useState(20);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    // نسبة المعهد
    const { data: inst } = await supabase
      .from("institutes")
      .select("institute_share_percent")
      .eq("id", id)
      .single();

    if (inst) setSharePercent(inst.institute_share_percent);

    // جلب مواد الطالب مع الأستاذ
    const { data: sbjs } = await supabase
      .from("student_subjects")
      .select(`
        id,
        subject_id ( id, name ),
        teacher_id ( id, full_name )
      `)
      .eq("student_id", studentId);

    setSubjects(sbjs || []);
  };

  const savePayment = async () => {
    if (!selectedSubject || !amount) {
      setMsg("يرجى اختيار المادة وكتابة مبلغ الدفعة.");
      return;
    }

    const chosen = subjects.find((s) => s.id === selectedSubject);

    if (!chosen) {
      setMsg("خطأ: المادة المحددة غير موجودة");
      return;
    }

    const instituteShare = Math.floor((amount * sharePercent) / 100);
    const teacherShare = amount - instituteShare;

    const { error } = await supabase.from("payments").insert([
      {
        student_subject_id: selectedSubject,
        student_id: studentId,
        institute_id: id,
        subject_id: chosen.subject_id.id,
        teacher_id: chosen.teacher_id.id,
        amount,
        institute_share: instituteShare,
        teacher_share: teacherShare,
        date: new Date().toISOString().split("T")[0],
        note,
      },
    ]);

    if (error) {
      setMsg("خطأ في حفظ الدفعة: " + error.message);
      return;
    }

    router.push(`/dashboard/institutes/${id}/students/${studentId}`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>💵 إضافة دفعة جديدة</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 400 }}>

        <label>اختر المادة</label>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          style={{ padding: 10 }}
        >
          <option value="">— اختر مادة —</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.subject_id.name} — {s.teacher_id.full_name}
            </option>
          ))}
        </select>

        <label>المبلغ</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{ padding: 10 }}
        />

        <p>🏫 نسبة المعهد: {sharePercent}%</p>
        <p>👨‍🏫 نسبة الأستاذ: {100 - sharePercent}%</p>

        <label>ملاحظة (اختياري)</label>
        <textarea
          style={{ padding: 10 }}
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />

        <button
          onClick={savePayment}
          style={{
            padding: 12,
            background: "green",
            color: "white",
            borderRadius: 8,
          }}
        >
          💾 حفظ الدفعة
        </button>

        {msg && <p style={{ color: "red" }}>{msg}</p>}
      </div>
    </div>
  );
}
