"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function StudentPage() {
  const { id, studentId } = useParams();
  const router = useRouter();

  const [student, setStudent] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [payments, setPayments] = useState([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  // 🔄 تحميل بيانات الطالب + المواد + الدفعات
  const loadData = async () => {
    try {
      setLoading(true);
      setMsg("");

      // 📌 بيانات الطالب
      const { data: stData, error: stError } = await supabase
        .from("students")
        .select(
          `
          *,
          stage_id(*),
          group_id(*)
        `
        )
        .eq("id", studentId)
        .single();

      if (stError) throw stError;
      setStudent(stData);

      // 📌 مواد الطالب
      const { data: sbjData, error: sbjError } = await supabase
        .from("student_subjects")
        .select(
          `
          *,
          subject_id(name),
          teacher_id(full_name)
        `
        )
        .eq("student_id", studentId);

      if (sbjError) throw sbjError;
      setSubjects(sbjData || []);

      // 📌 دفعات الطالب
      const { data: payData, error: payError } = await supabase
        .from("payments")
        .select("*")
        .eq("student_id", studentId)
        .order("date", { ascending: false });

      if (payError) throw payError;
      setPayments(payData || []);

    } catch (err) {
      console.log(err);
      setMsg("حدث خطأ: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return <p style={{ padding: 40 }}>جاري تحميل بيانات الطالب...</p>;
  }

  if (!student) {
    return (
      <div dir="rtl" style={{ padding: 40 }}>
        <p style={{ color: "red" }}>لم يتم العثور على بيانات هذا الطالب.</p>
      </div>
    );
  }

  // 💰 حساب الحالة المالية
  const totalSubjectFees = subjects.reduce(
    (acc, s) => acc + (s.total_fee || 0),
    0
  );
  const totalPaid = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const remaining = totalSubjectFees - totalPaid;

  // 🗑️ حذف الطالب
  const deleteStudent = async () => {
    if (!confirm("هل تريد حذف هذا الطالب؟")) return;

    await supabase.from("students").delete().eq("id", studentId);
    router.push(`/dashboard/institutes/${id}/students`);
  };

  return (
    <div dir="rtl" style={{ padding: 40, maxWidth: 900, margin: "0 auto" }}>

      {/* ✔ اسم الطالب */}
      <h1 style={{ fontSize: 28, marginBottom: 20 }}>
        👨‍🎓 {student.full_name}
      </h1>

      {/* ✔ معلومات الطالب */}
      <div
        style={{
          background: "#f8f8f8",
          padding: 20,
          borderRadius: 10,
          marginBottom: 20,
        }}
      >
        <p>📘 المرحلة: {student.stage_id?.name || "—"}</p>
        <p>👥 الكروب: {student.group_id?.name || "—"}</p>
        <p>🏫 المدرسة: {student.school || "—"}</p>
        <p>📞 هاتف الطالب: {student.phone}</p>
        <p>📞 هاتف ولي الأمر: {student.parent_phone}</p>
        <p>🎂 تاريخ الميلاد: {student.birth_date}</p>
      </div>

      {/* ✔ الحالة المالية */}
      <div
        style={{
          background: "#e3f2fd",
          padding: 20,
          borderRadius: 10,
          marginBottom: 25,
        }}
      >
        <h3>💰 الحالة المالية</h3>
        <p>أجور المواد: {totalSubjectFees} د.ع</p>
        <p>المدفوع: {totalPaid} د.ع</p>
        <p style={{ color: remaining > 0 ? "red" : "green" }}>
          المتبقي: {remaining} د.ع
        </p>
      </div>

      {/* ✔ الأزرار */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 10,
          marginBottom: 30,
          padding: 10,
          background: "#f5f5f5",
          borderRadius: 10,
        }}
      >
        <Button text="➕ إضافة مادة" color="#1976d2"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/add-subject`)}
        />

        <Button text="💵 إضافة دفعة" color="green"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/add-payment`)}
        />

        <Button text="📚 مواد الطالب" color="#455a64"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/subjects`)}
        />

        <Button text="💳 دفعات الطالب" color="#6d4c41"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/payments`)}
        />

        <Button text="📋 تقرير الحضور" color="#9c27b0"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/attendance`)}
        />

        <Button text="🖨️ طباعة" color="#444"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/print`)}
        />

        <Button text="✏️ تعديل بيانات" color="#0288d1"
          onClick={() => router.push(`/dashboard/institutes/${id}/students/${studentId}/edit`)}
        />

        <Button text="🗑️ حذف الطالب" color="darkred"
          onClick={deleteStudent}
        />
      </div>

      {msg && <p style={{ color: "red" }}>{msg}</p>}
    </div>
  );
}

// 🔘 زر جاهز للاستخدام
function Button({ text, color, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "10px 16px",
        background: color,
        color: "white",
        borderRadius: 8,
        minWidth: 140,
      }}
    >
      {text}
    </button>
  );
}
