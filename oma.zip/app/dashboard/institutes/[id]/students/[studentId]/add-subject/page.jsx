"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function AddStudentSubjectPage() {
  const { id, studentId } = useParams(); // id = institute_id
  const router = useRouter();

  const [subjects, setSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [selectedTeacherId, setSelectedTeacherId] = useState("");
  const [totalFee, setTotalFee] = useState("");
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadLookups = async () => {
    setMsg("");
    setLoading(true);

    // المواد
    const { data: sbjData, error: sbjErr } = await supabase
      .from("subjects")
      .select("*")
      .eq("institute_id", id)
      .order("name", { ascending: true });

    // الأساتذة
    const { data: tchData, error: tchErr } = await supabase
      .from("teachers")
      .select("*")
      .eq("institute_id", id)
      .order("full_name", { ascending: true });

    if (sbjErr) setMsg("خطأ في تحميل المواد: " + sbjErr.message);
    if (tchErr) setMsg((prev) => prev + "\nخطأ في تحميل الأساتذة: " + tchErr.message);

    setSubjects(sbjData || []);
    setTeachers(tchData || []);

    setLoading(false);
  };

  useEffect(() => {
    loadLookups();
  }, []);

  const save = async (e) => {
    e.preventDefault();
    setMsg("");
    setSaving(true);

    if (!selectedSubjectId || !selectedTeacherId || !totalFee) {
      setMsg("الرجاء اختيار مادة وأستاذ وإدخال الأجر.");
      setSaving(false);
      return;
    }

    const subjectObj = subjects.find((s) => s.id === selectedSubjectId) || null;
    const teacherObj = teachers.find((t) => t.id === selectedTeacherId) || null;

    const { error } = await supabase.from("student_subjects").insert([
      {
        student_id: studentId,
        subject_id: selectedSubjectId,
        teacher_id: selectedTeacherId,
        total_fee: Number(totalFee) || 0,

        // للحفاظ على التوافق مع الجدول القديم
        subject_name: subjectObj ? subjectObj.name : null,
      },
    ]);

    if (error) {
      setMsg("خطأ في حفظ المادة للطالب: " + error.message);
      setSaving(false);
      return;
    }

    setMsg("✔️ تم إضافة المادة للطالب بنجاح");
    router.push(`/dashboard/institutes/${id}/students/${studentId}`);
  };

  if (loading) {
    return <p style={{ padding: 40 }}>جاري تحميل البيانات...</p>;
  }

  return (
    <div dir="rtl" style={{ padding: 40, maxWidth: 700, margin: "0 auto" }}>
      <h1 style={{ marginBottom: 20 }}>➕ إضافة مادة للطالب</h1>

      <form onSubmit={save} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <label>المادة</label>
        <select
          value={selectedSubjectId}
          onChange={(e) => setSelectedSubjectId(e.target.value)}
          style={{ padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
        >
          <option value="">اختر المادة</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>

        <label>الأستاذ</label>
        <select
          value={selectedTeacherId}
          onChange={(e) => setSelectedTeacherId(e.target.value)}
          style={{ padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
        >
          <option value="">اختر الأستاذ</option>
          {teachers.map((t) => (
            <option key={t.id} value={t.id}>
              {t.full_name}
            </option>
          ))}
        </select>

        <label>سعر المادة (د.ع)</label>
        <input
          type="number"
          value={totalFee}
          onChange={(e) => setTotalFee(e.target.value)}
          placeholder="مثال: 25000"
          style={{ padding: 10, borderRadius: 6, border: "1px solid #ccc" }}
        />

        <button
          type="submit"
          disabled={saving}
          style={{
            padding: 12,
            background: "#2e7d32",
            color: "white",
            borderRadius: 8,
            border: "none",
            marginTop: 10,
            cursor: "pointer",
          }}
        >
          {saving ? "جارٍ الحفظ..." : "💾 حفظ المادة للطالب"}
        </button>
      </form>

      {msg && (
        <p style={{ color: msg.includes("خطأ") ? "red" : "green", marginTop: 20 }}>
          {msg}
        </p>
      )}
    </div>
  );
}
