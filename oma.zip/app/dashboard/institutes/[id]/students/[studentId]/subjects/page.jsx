"use client";

import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function StudentSubjects() {
  const { id, studentId } = useParams();
  const router = useRouter();
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSubjects();
  }, []);

  const loadSubjects = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("student_subjects")
      .select(`
        id,
        subject_name,
        total_fee,
        teacher_id(full_name)
      `)
      .eq("student_id", studentId);

    if (!error) setSubjects(data || []);

    setLoading(false);
  };

  const deleteSubject = async (subjectId) => {
    if (!confirm("هل تريد حذف هذه المادة من جدول الطالب؟")) return;

    const { error } = await supabase
      .from("student_subjects")
      .delete()
      .eq("id", subjectId);

    if (!error) {
      loadSubjects(); // تحديث الصفحة بعد الحذف
    }
  };

  if (loading) {
    return <p style={{ padding: 40 }}>جاري تحميل المواد...</p>;
  }

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📚 مواد الطالب</h1>

      {subjects.length === 0 && <p>لا توجد مواد لهذا الطالب.</p>}

      {subjects.map((s) => (
        <div
          key={s.id}
          style={{
            padding: 15,
            border: "1px solid #ccc",
            borderRadius: 10,
            marginBottom: 10,
            background: "#fafafa",
          }}
        >
          <p>📘 المادة: {s.subject_name}</p>
          <p>👨‍🏫 الأستاذ: {s.teacher_id?.full_name || "—"}</p>
          <p>💵 السعر: {s.total_fee}</p>

          {/* أزرار الإجراءات */}
          <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
            <button
              onClick={() =>
                router.push(
                  `/dashboard/institutes/${id}/students/${studentId}/subjects/${s.id}/edit`
                )
              }
              style={{
                padding: "8px 14px",
                background: "#1976d2",
                color: "white",
                borderRadius: 8,
              }}
            >
              ✏️ تعديل
            </button>

            <button
              onClick={() => deleteSubject(s.id)}
              style={{
                padding: "8px 14px",
                background: "darkred",
                color: "white",
                borderRadius: 8,
              }}
            >
              🗑️ حذف
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
