"use client";

import { useParams, useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";

export default function EditStudentSubject() {
  const { id, studentId, subjectItemId } = useParams();
  const router = useRouter();

  const [teachers, setTeachers] = useState([]);
  const [form, setForm] = useState({
    subject_name: "",
    total_fee: "",
    teacher_id: "",
  });

  const [msg, setMsg] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  // تحميل الأساتذة + المادة الحالية
  const loadData = async () => {
    // تحميل الأساتذة
    const { data: teachersData } = await supabase
      .from("teachers")
      .select("id, full_name, subject_name")
      .eq("institute_id", id);

    setTeachers(teachersData || []);

    // تحميل المادة الحالية
    const { data: subj } = await supabase
      .from("student_subjects")
      .select("*")
      .eq("id", subjectItemId)
      .single();

    if (subj) {
      setForm({
        subject_name: subj.subject_name,
        total_fee: subj.total_fee,
        teacher_id: subj.teacher_id,
      });
    }
  };

  // حفظ التعديلات
  const saveChanges = async () => {
    if (!form.teacher_id || !form.total_fee) {
      setMsg("يرجى تعبئة جميع الحقول");
      return;
    }

    const { error } = await supabase
      .from("student_subjects")
      .update({
        subject_name: form.subject_name,
        total_fee: form.total_fee,
        teacher_id: form.teacher_id,
      })
      .eq("id", subjectItemId);

    if (error) {
      setMsg("خطأ: " + error.message);
    } else {
      router.push(`/dashboard/institutes/${id}/students/${studentId}/subjects`);
    }
  };

  return (
    <div dir="rtl" style={{ padding: 40, maxWidth: 450 }}>
      <h1>✏️ تعديل مادة الطالب</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        
        <label>اسم المادة</label>
        <input
          style={{ padding: 10 }}
          value={form.subject_name}
          onChange={(e) =>
            setForm({ ...form, subject_name: e.target.value })
          }
        />

        <label>الأستاذ</label>
        <select
          style={{ padding: 10 }}
          value={form.teacher_id}
          onChange={(e) =>
            setForm({ ...form, teacher_id: e.target.value })
          }
        >
          <option value="">— اختر أستاذ —</option>
          {teachers.map((t) => (
            <option key={t.id} value={t.id}>
              {t.subject_name} — {t.full_name}
            </option>
          ))}
        </select>

        <label>السعر</label>
        <input
          type="number"
          style={{ padding: 10 }}
          value={form.total_fee}
          onChange={(e) =>
            setForm({ ...form, total_fee: e.target.value })
          }
        />

        <button
          onClick={saveChanges}
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
          }}
        >
          💾 حفظ التعديلات
        </button>

        {msg && <p style={{ color: "red" }}>{msg}</p>}
      </div>
    </div>
  );
}
