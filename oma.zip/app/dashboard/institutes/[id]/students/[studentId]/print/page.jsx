"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function PrintStudentCard() {
  const { id, studentId } = useParams();

  const [institute, setInstitute] = useState(null);
  const [student, setStudent] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAll();
    setTimeout(() => window.print(), 800);
  }, []);

  const loadAll = async () => {
    // معلومات المعهد
    const { data: inst } = await supabase
      .from("institutes")
      .select("*")
      .eq("id", id)
      .single();
    setInstitute(inst);

    // معلومات الطالب
    const { data: std } = await supabase
      .from("students")
      .select("*, stage_id(*), group_id(*)")
      .eq("id", studentId)
      .single();
    setStudent(std);

    // المواد
    const { data: sbj } = await supabase
      .from("student_subjects")
      .select(`
        id,
        total_fee,
        subject_id ( name ),
        teacher_id ( full_name )
      `)
      .eq("student_id", studentId);
    setSubjects(sbj || []);

    // الدفعات
    const { data: pay } = await supabase
      .from("payments")
      .select("*")
      .eq("student_id", studentId)
      .order("date", { ascending: true });
    setPayments(pay || []);

    setLoading(false);
  };

  if (loading || !student || !institute) {
    return <p style={{ padding: 50 }}>جاري التحميل...</p>;
  }

  // الحسابات المالية
  const totalSubjects = subjects.reduce((acc, s) => acc + (s.total_fee || 0), 0);
  const totalPaid = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const remaining = totalSubjects - totalPaid;

  return (
    <div
      style={{
        width: "210mm",
        minHeight: "297mm",
        margin: "0 auto",
        padding: "15mm",
        background: "white",
        fontFamily: "Times New Roman",
        fontSize: "15px",
        color: "#000",
      }}
    >
      {/* ====== رأس الاستمارة ====== */}
      <div style={{ textAlign: "center", marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 28, color: "#004d99" }}>
          {institute.name}
        </h1>
        <p style={{ margin: 0 }}>{institute.address || ""}</p>
        <p style={{ margin: 0 }}>هاتف: {institute.phone || ""}</p>
      </div>

      <hr style={{ border: "1px solid #004d99", margin: "20px 0" }} />

      {/* ====== عنوان النموذج ====== */}
      <h2
        style={{
          textAlign: "center",
          fontSize: 22,
          color: "#004d99",
          marginBottom: 30,
        }}
      >
        استمارة بيانات الطالب الرسمية
      </h2>

      {/* ====== معلومات الطالب ====== */}
      <div style={{ marginBottom: 30 }}>
        <h3 style={{ color: "#004d99", borderBottom: "2px solid #004d99" }}>
          1) معلومات الطالب
        </h3>

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <tbody>
            <tr>
              <td style={cellLeft}>الاسم الكامل:</td>
              <td style={cellRight}>{student.full_name}</td>
            </tr>
            <tr>
              <td style={cellLeft}>رقم الهاتف:</td>
              <td style={cellRight}>{student.phone}</td>
            </tr>
            <tr>
              <td style={cellLeft}>ولي الأمر:</td>
              <td style={cellRight}>{student.parent_phone}</td>
            </tr>
            <tr>
              <td style={cellLeft}>المدرسة:</td>
              <td style={cellRight}>{student.school}</td>
            </tr>
            <tr>
              <td style={cellLeft}>المرحلة:</td>
              <td style={cellRight}>{student.stage_id?.name}</td>
            </tr>
            <tr>
              <td style={cellLeft}>الكروب:</td>
              <td style={cellRight}>{student.group_id?.name}</td>
            </tr>
            <tr>
              <td style={cellLeft}>تاريخ الميلاد:</td>
              <td style={cellRight}>{student.birth_date}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* ====== التقرير المالي ====== */}
      <div style={{ marginBottom: 30 }}>
        <h3 style={{ color: "#004d99", borderBottom: "2px solid #004d99" }}>
          2) التقرير المالي
        </h3>

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <tbody>
            <tr>
              <td style={cellLeft}>المبالغ المستحقة:</td>
              <td style={cellRight}>{totalSubjects} د.ع</td>
            </tr>
            <tr>
              <td style={cellLeft}>المدفوع:</td>
              <td style={{ ...cellRight, color: "green" }}>{totalPaid} د.ع</td>
            </tr>
            <tr>
              <td style={cellLeft}>المتبقي:</td>
              <td style={{ ...cellRight, color: "red" }}>{remaining} د.ع</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* ====== المواد ====== */}
      <div style={{ marginBottom: 30 }}>
        <h3 style={{ color: "#004d99", borderBottom: "2px solid #004d99" }}>
          3) المواد التي يدرسها الطالب
        </h3>

        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: 10,
          }}
        >
          <thead>
            <tr style={{ background: "#cce6ff" }}>
              <th style={cellHeader}>المادة</th>
              <th style={cellHeader}>الأستاذ</th>
              <th style={cellHeader}>الأجور</th>
            </tr>
          </thead>

          <tbody>
            {subjects.map((s) => (
              <tr key={s.id}>
                <td style={cellBorder}>{s.subject_id.name}</td>
                <td style={cellBorder}>{s.teacher_id.full_name}</td>
                <td style={cellBorder}>{s.total_fee} د.ع</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ====== الختم والتوقيع ====== */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: 60,
          marginBottom: 40,
        }}
      >
        <div style={{ textAlign: "center" }}>
          <p style={{ marginBottom: 5 }}>ختم المعهد</p>
          <div
            style={{
              width: 120,
              height: 120,
              border: "2px solid #004d99",
              borderRadius: "10px",
            }}
          />
        </div>

        <div style={{ textAlign: "center" }}>
          <p style={{ marginBottom: 5 }}>توقيع الطالب</p>
          <div
            style={{
              width: 200,
              height: 40,
              borderBottom: "2px solid #004d99",
            }}
          />
        </div>
      </div>
    </div>
  );
}

/* ====== تنسيقات الخلايا ====== */

const cellLeft = {
  padding: "8px",
  fontWeight: "bold",
  width: "30%",
  border: "1px solid #004d99",
  background: "#e6f3ff",
};

const cellRight = {
  padding: "8px",
  border: "1px solid #004d99",
};

const cellHeader = {
  padding: "10px",
  border: "1px solid #004d99",
  textAlign: "center",
  fontSize: "16px",
  fontWeight: "bold",
};

const cellBorder = {
  padding: "10px",
  border: "1px solid #004d99",
  textAlign: "center",
};
