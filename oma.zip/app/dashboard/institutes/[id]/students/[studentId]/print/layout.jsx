export default function PrintLayout({ children }) {
  return (
    <div style={{ background: "white", padding: 0, margin: 0 }}>
      {children}
    </div>
  );
}
