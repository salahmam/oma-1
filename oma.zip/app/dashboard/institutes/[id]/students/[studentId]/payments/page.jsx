"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function StudentPaymentsPage() {
  const { id, studentId } = useParams();

  const [payments, setPayments] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [studentSubjects, setStudentSubjects] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    // 1) جلب دفعات الطالب
    const { data: payData, error: payError } = await supabase
      .from("payments")
      .select("*")
      .eq("student_id", studentId)
      .order("date", { ascending: false });

    if (payError) {
      console.error(payError);
      setMsg("خطأ في جلب الدفعات");
      return;
    }

    setPayments(payData || []);

    // 2) جلب المواد
    const { data: subjectsData } = await supabase
      .from("subjects")
      .select("id, name");

    setSubjects(subjectsData || []);

    // 3) جلب الأساتذة
    const { data: teachersData } = await supabase
      .from("teachers")
      .select("id, full_name");

    setTeachers(teachersData || []);

    // 4) جلب مواد الطالب مع الأسعار
    const { data: stuSubData } = await supabase
      .from("student_subjects")
      .select("id, monthly_price, subject_id")
      .eq("student_id", studentId);

    setStudentSubjects(stuSubData || []);
  };

  // 🔽 أسماء المواد والأساتذة
  const getSubjectName = (subjectId) =>
    subjects.find((s) => s.id === subjectId)?.name || "—";

  const getTeacherName = (teacherId) =>
    teachers.find((t) => t.id === teacherId)?.full_name || "—";

  // 🔥 حساب التقرير الجديد
  const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalInstitute = payments.reduce((sum, p) => sum + p.institute_share, 0);
  const totalTeacher = payments.reduce((sum, p) => sum + p.teacher_share, 0);
  const countPayments = payments.length;

  // 🔥 مجموع أجور الطالب من جدول student_subjects
  const totalSubjectFees = studentSubjects.reduce(
    (sum, s) => sum + Number(s.monthly_price || 0),
    0
  );

  const remaining = totalSubjectFees - totalPaid;

  const deletePayment = async (paymentId) => {
    if (!confirm("هل تريد حذف هذه الدفعة؟")) return;
    await supabase.from("payments").delete().eq("id", paymentId);
    loadAll();
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>💵 سجل دفعات الطالب</h1>

      {/* 🔥 تقرير مالي كامل */}
      <div
        style={{
          background: "#e3f2fd",
          padding: 20,
          borderRadius: 10,
          marginBottom: 30,
        }}
      >
        <h3>📊 تقرير الدفعات</h3>
        <p>💰 مجموع أجور المواد: {totalSubjectFees.toLocaleString()} د.ع</p>
        <p>💵 مجموع المدفوعات: {totalPaid.toLocaleString()} د.ع</p>
        <p style={{ color: remaining > 0 ? "red" : "green" }}>
          🧾 المتبقي: {remaining.toLocaleString()} د.ع
        </p>

        <hr />

        <p>🏫 مجموع حصة المعهد: {totalInstitute.toLocaleString()} د.ع</p>
        <p>👨‍🏫 مجموع حصة الأستاذ: {totalTeacher.toLocaleString()} د.ع</p>
        <p>🧾 عدد الدفعات: {countPayments}</p>
      </div>

      {payments.length === 0 && <p>لا توجد دفعات لهذا الطالب.</p>}

      {payments.map((p) => (
        <div
          key={p.id}
          style={{
            padding: 15,
            border: "1px solid #ccc",
            borderRadius: 10,
            marginBottom: 10,
            background: "#fafafa",
          }}
        >
          <p>📘 المادة: {getSubjectName(p.subject_id)}</p>
          <p>👨‍🏫 الأستاذ: {getTeacherName(p.teacher_id)}</p>

          <p>💵 المبلغ: {p.amount.toLocaleString()} د.ع</p>
          <p>🏫 حصة المعهد: {p.institute_share.toLocaleString()} د.ع</p>
          <p>👨‍🏫 حصة الأستاذ: {p.teacher_share.toLocaleString()} د.ع</p>

          <p>📅 التاريخ: {p.date}</p>

          {p.note && <p>📝 ملاحظة: {p.note}</p>}

          <button
            onClick={() => deletePayment(p.id)}
            style={{
              padding: 8,
              background: "darkred",
              color: "white",
              borderRadius: 8,
              marginTop: 10,
            }}
          >
            🗑️ حذف الدفعة
          </button>
        </div>
      ))}

      {msg && <p style={{ color: "red" }}>{msg}</p>}
    </div>
  );
}
