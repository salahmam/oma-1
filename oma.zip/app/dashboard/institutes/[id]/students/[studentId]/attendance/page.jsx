"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function StudentAttendance() {
  const { id, studentId } = useParams();

  const [records, setRecords] = useState([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAttendance();
  }, []);

  const loadAttendance = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("attendance_students")
      .select("id, date, status")
      .eq("student_id", studentId)
      .order("date", { ascending: false });

    if (error) {
      setMsg("خطأ في تحميل الحضور: " + error.message);
      setLoading(false);
      return;
    }

    setRecords(data || []);
    setLoading(false);
  };

  if (loading) {
    return <p style={{ padding: 40 }}>جاري تحميل بيانات الحضور...</p>;
  }

  // 🔥 حساب التقرير
  const presentCount = records.filter((r) => r.status === "present").length;
  const absentCount = records.filter((r) => r.status === "absent").length;
  const total = records.length;

  const attendancePercent =
    total === 0 ? 0 : Math.round((presentCount / total) * 100);

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📋 تقرير حضور الطالب</h1>

      {/* 🔥 بطاقة التقرير */}
      <div
        style={{
          background: "#e3f2fd",
          padding: 20,
          borderRadius: 10,
          marginBottom: 30,
        }}
      >
        <h3>📊 الإحصائيات</h3>
        <p>✔️ عدد أيام الحضور: {presentCount}</p>
        <p>❌ عدد أيام الغياب: {absentCount}</p>
        <p>📅 مجموع الأيام المسجّلة: {total}</p>
        <p style={{ fontWeight: "bold", color: attendancePercent >= 50 ? "green" : "red" }}>
          📈 نسبة الحضور: {attendancePercent}%
        </p>
      </div>

      {/* 🔥 جدول الحضور */}
      {records.length === 0 ? (
        <p>لا يوجد حضور مسجل لهذا الطالب.</p>
      ) : (
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            textAlign: "center",
          }}
        >
          <thead>
            <tr style={{ background: "#ddd" }}>
              <th style={{ padding: 10 }}>التاريخ</th>
              <th style={{ padding: 10 }}>الحالة</th>
            </tr>
          </thead>

          <tbody>
            {records.map((r) => (
              <tr key={r.id} style={{ borderBottom: "1px solid #ccc" }}>
                <td style={{ padding: 10 }}>{r.date}</td>
                <td style={{ padding: 10 }}>
                  {r.status === "present" ? (
                    <span style={{ color: "green", fontWeight: "bold" }}>✔️ حاضر</span>
                  ) : (
                    <span style={{ color: "red", fontWeight: "bold" }}>❌ غائب</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {msg && <p style={{ color: "red", marginTop: 20 }}>{msg}</p>}
    </div>
  );
}
