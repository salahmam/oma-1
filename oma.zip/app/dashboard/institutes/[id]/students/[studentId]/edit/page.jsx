"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function EditStudent() {
  const { id, studentId } = useParams();
  const router = useRouter();

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    parent_phone: "",
    school: "",
    birth_date: "",
  });

  useEffect(() => {
    loadStudent();
  }, []);

  const loadStudent = async () => {
    const { data } = await supabase
      .from("students")
      .select("*")
      .eq("id", studentId)
      .single();

    if (data) setForm(data);
  };

  const saveStudent = async () => {
    const { error } = await supabase
      .from("students")
      .update(form)
      .eq("id", studentId);

    if (!error)
      router.push(`/dashboard/institutes/${id}/students/${studentId}`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>✏️ تعديل بيانات الطالب</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 400 }}>
        <label>اسم الطالب</label>
        <input
          value={form.full_name}
          onChange={(e) => setForm({ ...form, full_name: e.target.value })}
          style={{ padding: 10 }}
        />

        <label>رقم الهاتف</label>
        <input
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          style={{ padding: 10 }}
        />

        <label>هاتف ولي الأمر</label>
        <input
          value={form.parent_phone}
          onChange={(e) => setForm({ ...form, parent_phone: e.target.value })}
          style={{ padding: 10 }}
        />

        <label>المدرسة</label>
        <input
          value={form.school}
          onChange={(e) => setForm({ ...form, school: e.target.value })}
          style={{ padding: 10 }}
        />

        <label>تاريخ الميلاد</label>
        <input
          type="date"
          value={form.birth_date}
          onChange={(e) => setForm({ ...form, birth_date: e.target.value })}
          style={{ padding: 10 }}
        />

        <button
          onClick={saveStudent}
          style={{
            padding: 12,
            background: "#0288d1",
            color: "white",
            borderRadius: 8,
          }}
        >
          💾 حفظ التعديلات
        </button>
      </div>
    </div>
  );
}
