"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function InstituteSettings() {
  const { id } = useParams();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [sharePercent, setSharePercent] = useState(20);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const { data } = await supabase
      .from("institutes")
      .select("*")
      .eq("id", id)
      .single();

    if (data) {
      setName(data.name);
      setDescription(data.description || "");
      setSharePercent(data.institute_share_percent || 20);
    }
  };

  const save = async () => {
    const { error } = await supabase
      .from("institutes")
      .update({
        name,
        description,
        institute_share_percent: sharePercent,
      })
      .eq("id", id);

    if (error) setMsg("خطأ: " + error.message);
    else setMsg("✔️ تم حفظ الإعدادات بنجاح");
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>⚙️ إعدادات المعهد</h1>

      <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 400 }}>
        <label>اسم المعهد</label>
        <input value={name} onChange={(e) => setName(e.target.value)} style={{ padding: 10 }} />

        <label>الوصف</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} style={{ padding: 10 }} />

        <label>نسبة المعهد (٪)</label>
        <input
          type="number"
          min="0"
          max="100"
          value={sharePercent}
          onChange={(e) => setSharePercent(e.target.value)}
          style={{ padding: 10 }}
        />

        <button
          onClick={save}
          style={{
            padding: 12,
            background: "#1976d2",
            color: "white",
            borderRadius: 8,
            marginTop: 10,
          }}
        >
          💾 حفظ الإعدادات
        </button>

        {msg && <p style={{ color: "green" }}>{msg}</p>}
      </div>
    </div>
  );
}
