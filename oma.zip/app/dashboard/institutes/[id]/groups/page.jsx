"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function GroupsPage() {
  const { id } = useParams();
  const router = useRouter();

  const [groups, setGroups] = useState([]);

  useEffect(() => {
    supabase
      .from("groups")
      .select("*")
      .eq("institute_id", id)
      .order("name")
      .then(({ data }) => setGroups(data || []));
  }, []);

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>👥 الكروبات</h1>

      <button
        onClick={() => router.push(`/dashboard/institutes/${id}/groups/new`)}
        style={{
          padding: 10,
          background: "#ff7043",
          color: "white",
          borderRadius: 8,
          marginTop: 20,
        }}
      >
        ➕ إنشاء كروب جديد
      </button>

      <div style={{ marginTop: 25 }}>
        {groups.map((g) => (
          <div
            key={g.id}
            style={{
              padding: 15,
              border: "1px solid #ccc",
              borderRadius: 10,
              marginBottom: 10,
            }}
          >
            <p>👥 الكروب: {g.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
