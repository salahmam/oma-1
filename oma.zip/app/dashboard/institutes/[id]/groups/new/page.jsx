"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams, useRouter } from "next/navigation";

export default function NewGroup() {
  const { id } = useParams();
  const router = useRouter();

  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");

  const saveGroup = async () => {
    if (!name) {
      setMsg("يرجى كتابة اسم الكروب");
      return;
    }

    const { error } = await supabase.from("groups").insert([
      {
        name,
        institute_id: id,
      },
    ]);

    if (error) {
      setMsg("خطأ: " + error.message);
      return;
    }

    router.push(`/dashboard/institutes/${id}/groups`);
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>➕ إضافة كروب جديد</h1>

      <input
        style={{ padding: 12, borderRadius: 8, border: "1px solid #ccc", width: 300 }}
        placeholder="مثال: كروب A — سادس علمي"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button
        style={{
          padding: 12,
          background: "#2e7d32",
          color: "white",
          borderRadius: 8,
          marginTop: 12,
        }}
        onClick={saveGroup}
      >
        💾 حفظ
      </button>

      {msg && <p style={{ color: "red" }}>{msg}</p>}
    </div>
  );
}
