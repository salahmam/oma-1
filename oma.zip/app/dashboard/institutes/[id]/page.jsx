"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";
import Link from "next/link";

export default function InstituteDetails() {
  const { id } = useParams();
  const [institute, setInstitute] = useState(null);

  useEffect(() => {
    supabase
      .from("institutes")
      .select("*")
      .eq("id", id)
      .single()
      .then(({ data }) => setInstitute(data));
  }, []);

  if (!institute) return <p style={{ padding: 40 }}>جاري التحميل...</p>;

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1 style={{ fontSize: 30 }}>{institute.name}</h1>
      <p style={{ marginTop: 10, fontSize: 18 }}>{institute.description}</p>

      <div
        style={{
          marginTop: 30,
          display: "flex",
          flexDirection: "column",
          gap: 12,
          maxWidth: 350,
        }}
      >

        {/* العودة للوحة التحكم */}
        <Link
          href="/dashboard"
          style={buttonStyle("#424242")}
        >
          🏠 لوحة التحكم الرئيسية
        </Link>

        {/* إعدادات */}
        <Link
          href={`/dashboard/institutes/${id}/settings`}
          style={buttonStyle("#1976d2")}
        >
          ⚙️ إعدادات المعهد
        </Link>

        {/* الطلاب */}
        <Link
          href={`/dashboard/institutes/${id}/students`}
          style={buttonStyle("#00796b")}
        >
          👨‍🎓 الطلاب
        </Link>

        {/* الأساتذة */}
        <Link
          href={`/dashboard/institutes/${id}/teachers`}
          style={buttonStyle("#2e7d32")}
        >
          👨‍🏫 الأساتذة
        </Link>

        {/* المواد */}
        <Link
          href={`/dashboard/institutes/${id}/subjects`}
          style={buttonStyle("#8e24aa")}
        >
          📚 المواد
        </Link>

        {/* المراحل */}
        <Link
          href={`/dashboard/institutes/${id}/stages`}
          style={buttonStyle("#3949ab")}
        >
          📘 المراحل
        </Link>

        {/* الكروبات */}
        <Link
          href={`/dashboard/institutes/${id}/groups`}
          style={buttonStyle("#ff7043")}
        >
          👥 الكروبات
        </Link>

        {/* الدفعات */}
        <Link
          href={`/dashboard/institutes/${id}/payments`}
          style={buttonStyle("#6d4c41")}
        >
          💵 الدفعات
        </Link>

        {/* التقارير */}
        <Link
          href={`/dashboard/institutes/${id}/reports`}
          style={buttonStyle("#455a64")}
        >
          📊 التقارير
        </Link>

        {/* حضور الطلاب */}
        <Link
          href={`/dashboard/institutes/${id}/attendance/students`}
          style={buttonStyle("#0288d1")}
        >
          📝 حضور الطلاب
        </Link>

        {/* حضور الأساتذة */}
        <Link
          href={`/dashboard/institutes/${id}/attendance/teachers`}
          style={buttonStyle("#558b2f")}
        >
          🕒 حضور الأساتذة
        </Link>

        {/* جدول حصص */}
        <Link
          href={`/dashboard/institutes/${id}/schedule`}
          style={buttonStyle("#5e35b1")}
        >
          📅 جدول الحصص
        </Link>

        {/* إدارة المستخدمين */}
        <Link
          href={`/dashboard/institutes/${id}/users`}
          style={buttonStyle("#37474f")}
        >
          👤 إدارة المستخدمين
        </Link>

      </div>
    </div>
  );
}

// دالة الستايل لكل زر
function buttonStyle(bg) {
  return {
    padding: 12,
    background: bg,
    color: "white",
    borderRadius: 8,
    textAlign: "center",
    display: "block",
    textDecoration: "none",
    fontSize: 16,
  };
}
