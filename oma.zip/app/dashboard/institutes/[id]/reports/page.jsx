"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useParams } from "next/navigation";

export default function ReportsPage() {
  const { id } = useParams();

  const [payments, setPayments] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [sharePercent, setSharePercent] = useState(20);

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [expenseAmount, setExpenseAmount] = useState("");
  const [expenseNote, setExpenseNote] = useState("");

  useEffect(() => {
    loadInstituteSettings();
    loadData();
  }, []);

  // تحميل نسبة المعهد
  const loadInstituteSettings = async () => {
    const { data } = await supabase
      .from("institutes")
      .select("institute_share_percent")
      .eq("id", id)
      .single();

    if (data) setSharePercent(data.institute_share_percent);
  };

  // تحميل الدفعات والمصاريف
  const loadData = async () => {
    const { data: pay } = await supabase
      .from("payments")
      .select("amount, institute_share, teacher_share, date")
      .eq("institute_id", id);

    const { data: exp } = await supabase
      .from("expenses")
      .select("*")
      .eq("institute_id", id);

    setPayments(pay || []);
    setExpenses(exp || []);
  };

  // تطبيق الفلترة بتاريخ
  const filteredPayments = payments.filter((p) => {
    if (!startDate && !endDate) return true;

    const d = new Date(p.date);
    const s = startDate ? new Date(startDate) : null;
    const e = endDate ? new Date(endDate) : null;

    if (s && d < s) return false;
    if (e && d > e) return false;

    return true;
  });

  // حسابات نهائية
  const totalPayments = filteredPayments.reduce((a, p) => a + p.amount, 0);
  const totalInstitute = filteredPayments.reduce((a, p) => a + p.institute_share, 0);
  const totalTeachers = filteredPayments.reduce((a, p) => a + p.teacher_share, 0);

  const totalExpenses = expenses.reduce((a, e) => a + e.amount, 0);

  const netInstituteProfit = totalInstitute - totalExpenses;

  // إضافة مصروف جديد
  const addExpense = async () => {
    if (!expenseAmount.trim()) return;

    await supabase.from("expenses").insert([
      {
        institute_id: id,
        amount: expenseAmount,
        note: expenseNote,
        date: new Date().toISOString().split("T")[0],
      },
    ]);

    setExpenseAmount("");
    setExpenseNote("");
    loadData();
  };

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1>📊 تقارير المعهد</h1>

      {/* قسم الفلترة */}
      <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
        <div>
          <label>من تاريخ</label>
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </div>

        <div>
          <label>إلى تاريخ</label>
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
        </div>
      </div>

      {/* النتائج */}
      <div style={{ marginTop: 30, padding: 20, background: "#f4f4f4", borderRadius: 12 }}>
        <h2>💵 ملخص الدفعات</h2>

        <p>📌 مجموع الدفعات: {totalPayments.toLocaleString()} د.ع</p>
        <p>🏫 حصة المعهد: {totalInstitute.toLocaleString()} د.ع</p>
        <p>👨‍🏫 حصة الأساتذة: {totalTeachers.toLocaleString()} د.ع</p>

        <h2 style={{ marginTop: 20 }}>🧾 المصاريف</h2>
        <p>💸 مجموع المصاريف: {totalExpenses.toLocaleString()} د.ع</p>

        <h2 style={{ marginTop: 20 }}>💰 صافي ربح المعهد</h2>
        <p
          style={{
            fontSize: 22,
            color: netInstituteProfit >= 0 ? "green" : "red",
            fontWeight: "bold",
          }}
        >
          {netInstituteProfit.toLocaleString()} د.ع
        </p>
      </div>

      {/* قسم إضافة مصروف */}
      <div style={{ marginTop: 40, background: "#fafafa", padding: 20, borderRadius: 12 }}>
        <h3>➕ إضافة مصروف للمعهد</h3>

        <input
          type="number"
          placeholder="المبلغ"
          value={expenseAmount}
          onChange={(e) => setExpenseAmount(e.target.value)}
          style={{ padding: 10, width: "100%", marginTop: 10 }}
        />

        <textarea
          placeholder="ملاحظة (اختياري)"
          value={expenseNote}
          onChange={(e) => setExpenseNote(e.target.value)}
          style={{ padding: 10, width: "100%", marginTop: 10 }}
        />

        <button
          onClick={addExpense}
          style={{
            marginTop: 15,
            padding: 12,
            background: "brown",
            color: "white",
            borderRadius: 8,
            width: "100%",
          }}
        >
          💾 إضافة المصروف
        </button>
      </div>
    </div>
  );
}
