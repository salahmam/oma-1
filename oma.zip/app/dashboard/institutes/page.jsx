"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import Link from "next/link";

export default function InstitutesList() {
  const [institutes, setInstitutes] = useState([]);

  const loadData = async () => {
    const { data, error } = await supabase
      .from("institutes")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error) setInstitutes(data);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div dir="rtl" style={{ padding: 40 }}>
      <h1 style={{ fontSize: 30, marginBottom: 20 }}>قائمة المعاهد</h1>

      {institutes.length === 0 && <p>لا يوجد معاهد حتى الآن.</p>}

      <div style={{ display: "flex", flexDirection: "column", gap: 15 }}>
        {institutes.map((i) => (
          <Link
            key={i.id}
            href={`/dashboard/institutes/${i.id}`}
            style={{
              padding: 12,
              border: "1px solid #ccc",
              borderRadius: 8,
              background: "#f9f9f9",
            }}
          >
            {i.name}
          </Link>
        ))}
      </div>
    </div>
  );
}
